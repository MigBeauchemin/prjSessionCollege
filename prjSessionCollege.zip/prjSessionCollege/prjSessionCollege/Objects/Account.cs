﻿namespace prjSessionCollege.Objects
{
    public class Account
    {
        public int id { get; set; }
        public string username { get; set; }
        public string password { get; set; }       
    }
}
