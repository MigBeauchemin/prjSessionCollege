﻿namespace prjSessionCollege.Objects
{
    public class Department
    {
        public int id { get; set; }
        public string description { get; set; }
    }
}
