﻿namespace prjSessionCollege.Objects
{
    public class CourseSemesterStudent
    {
        public int id { get; set; }
        public int fkCourseSemesterId { get; set; }
        public int fkStudentId { get; set; }
        public double MiSession { get; set; } //decimal (5,2) default (0)//
        public double ExamenFinal { get; set; } //decimal (5,2) default (0)//
        public double ProjetDeSession { get; set; } //decimal (5,2) default (0)//
        public double CurrentGrade { get; set; } //decimal (5,2) default (0)//

        public double grade { get; set; } //decimal (5,2) default (0)//

        public string CourseDescription { get; set; } //Va venir de la table Course
        public string SemesterDescription { get; set; } //Va venir de la table CourseSemester
        public string StudentName { get; set; } //Va venir de la table Person (Student)

    }
}
