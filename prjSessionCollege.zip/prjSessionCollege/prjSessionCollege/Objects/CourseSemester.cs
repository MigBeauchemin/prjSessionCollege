﻿namespace prjSessionCollege.Objects
{
    public class CourseSemester
    {
        public int id { get; set; }
        public int fkCoursId { get; set; }
        public int fkSemesterId { get; set; }
        public int fkTeacherId { get; set; }
        public string schedule { get; set; } //default ""
        public string location { get; set; } //default ""

    }
}
