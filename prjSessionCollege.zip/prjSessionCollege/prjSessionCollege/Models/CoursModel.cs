﻿namespace prjSessionCollege.Models
{
    public class CoursModel
    {
        
    }
}
