﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using prjSessionCollege.Controllers;
using prjSessionCollege.Models;
using System.Net.Http.Headers;
using System.Text.Json;
using prjSessionCollege.JSON;
using prjSessionCollege.Objects;




namespace prjSessionCollege.Models
{
    public class HomeViewModel
    {
        private static HomeViewModel instance = null;

        public static HomeViewModel getInstance()
        {
            if (HomeViewModel.instance == null)
            {
                HomeViewModel.instance = new HomeViewModel();
            }

            return HomeViewModel.instance;
        }

        private List<Person> dataPersons = new List<Person>();
        private List<Semester> dataSemesters = new List<Semester>();
        private List<Department> dataDepartments = new List<Department>();
        private List<CourseSemester> dataCourseSemester = new List<CourseSemester>();

        private string errorMessage = "";


        public async Task CourseSemesterGetAll()
        {
            try
            {

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:7219/");
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //GET Method
                    string method = "CourseSemesterGetAll";
                    string parameters = "{\"parameters\":\"[]\"}"; //aucun parametre

                    HttpResponseMessage response = await client.GetAsync("College?method=" + method + "&parameters=" + parameters);

                    if (response.IsSuccessStatusCode)
                    {

                        string responseSTR = await response.Content.ReadAsStringAsync();

                        string cleanResponse = "";
                        cleanResponse = responseSTR.Replace(@"\", "");
                        cleanResponse = cleanResponse.Substring(1, cleanResponse.Length - 2);

                        ResponseJSONCourseSemesters responseJSON = JsonSerializer.Deserialize<ResponseJSONCourseSemesters>(cleanResponse);

                        this.dataCourseSemester = responseJSON.data;

                        // Success
                    }
                    else
                    {
                        // Message a l'utilisateur
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Try/Catch Error");
            }
        }

        /*public async Task SemesterGetAll()
        {
            try
            {

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:7294/");
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //GET Method
                    string method = "CourseSemesterGetAll";
                    string parameters = "{\"parameters\":\"[]\"}"; //aucun parametre

                    HttpResponseMessage response = await client.GetAsync("College?method=" + method + "&parameters=" + parameters);

                    if (response.IsSuccessStatusCode)
                    {

                        string responseSTR = await response.Content.ReadAsStringAsync();

                        string cleanResponse = "";
                        cleanResponse = responseSTR.Replace(@"\", "");
                        cleanResponse = cleanResponse.Substring(1, cleanResponse.Length - 2);

                        ResponseJSONSemester responseJSON = JsonSerializer.Deserialize<ResponseJSONSemester>(cleanResponse);

                        this.dataSemesters = responseJSON.data;

                        // Success
                    }
                    else
                    {
                        // Message a l'utilisateur
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Try/Catch Error");
            }
        }*/

        public async Task PersonGetAll()
        {

            try
            {

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:7294/");
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //GET Method
                    string method = "PersonGetAll";
                    string parameters = "{\"parameters\":\"[]\"}"; //"Teacher" ou "Student"

                    HttpResponseMessage response = await client.GetAsync("College?method=" + method + "&parameters=" + parameters);

                    if (response.IsSuccessStatusCode)
                    {

                        string responseSTR = await response.Content.ReadAsStringAsync();

                        string cleanResponse = "";
                        cleanResponse = responseSTR.Replace(@"\", "");
                        cleanResponse = cleanResponse.Substring(1, cleanResponse.Length - 2);

                        ResponseJSONPerson responseJSON = JsonSerializer.Deserialize<ResponseJSONPerson>(cleanResponse);

                        this.dataPersons = responseJSON.data;

                        // Success
                    }
                    else
                    {
                        // Message a l'utilisateur
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Try/Catch Error");
            }

        }

        /* public List<CourseSemester> DataCourseSemesters
         {
             get
             {
                 return this.dataCourseSemesters.OrderBy(cs => cs.LastName).ToList();
             }
         }*/

        public async Task UpdatePerson(string FirstName, string LastName, string Phone, string Email, string Role)
        {

            try
            {

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:7219/");
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));


                    string method = "PersonUpdateInfo";

                    string parameters = "{\"parameters\":[\"" + FirstName + "\",\"" + LastName + "\",\"" + Phone + "\",\"" + Email + "\",\"" + DateTime.Now + "\",\"" + Role + "\"]}";

                    HttpResponseMessage response = await client.PostAsync("College?method=" + method + "&parameters=" + parameters, new StringContent(""));

                    if (response.IsSuccessStatusCode)
                    {


                        string responseSTR = await response.Content.ReadAsStringAsync();

                        string cleanResponse = "";
                        cleanResponse = responseSTR.Replace(@"\", "");
                        cleanResponse = cleanResponse.Substring(1, cleanResponse.Length - 2);

                        ResponseJSON responseJSON = JsonSerializer.Deserialize<ResponseJSON>(cleanResponse);

                        if (responseJSON.status == "success")
                        {
                            int y = 0;
                        }
                        else
                        {
                            int z = 0;
                        }

                        // Success
                    }
                    else
                    {
                        int x = 0;
                        // Message a l'utilisateur
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Try/Catch Error");
            }

        }

        public string ErrorMessage
        {
            get { return this.errorMessage; }
        }
    }
}