﻿namespace prjSessionCollege.Models
{
    public class MainModel
    {
        public MainModel() { }
    }
}
