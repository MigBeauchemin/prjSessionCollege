﻿using System.Data;
using System.Data.SqlClient;
using Microsoft.AspNetCore.Mvc;
using prjSessionCollege.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using prjSessionCollege.Controllers;

namespace prjSessionCollege.Models
{
    public class ConnexionModel
    {
        public string Utilisateur { get; set; }
        public string Password { get; set; }
    }
}