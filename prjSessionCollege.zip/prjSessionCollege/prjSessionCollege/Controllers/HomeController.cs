﻿using Microsoft.AspNetCore.Mvc;
using prjSessionCollege.Models;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Net.Http;


namespace prjSessionCollege.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [HttpPost]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return View("Connexion");
        }

        public IActionResult Connexion(string username, string password)
        {
            if (username != null && password != null)
            {
                using (SqlConnection conn = new SqlConnection("Server=DESKTOP-AA4CU01\\erikz;Database=COLLEGE;Integrated Security=True;"))
                {
                    conn.Open();
                    string query = "SELECT * FROM Account WHERE Username = @username AND Password = @password";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", password);
                        object result = cmd.ExecuteScalar();

                        if (result != null)
                        {
                         int id = Convert.ToInt32(result);
                            query = "SELECT role FROM Person WHERE id = @id";
                            cmd.CommandText = query;
                            cmd.Parameters.Clear();
                            cmd.Parameters.AddWithValue("@id", id);

                            object roleObj = cmd.ExecuteScalar();
                            if (roleObj != null)
                            {
                                string role = roleObj.ToString();
                                HttpContext.Session.SetString("username", username);
                                HttpContext.Session.SetString("role", role);
                                
                                if (role == "Teacher")
                                {
                                    return RedirectToAction("TeacherPage");
                                }
                                else if (role == "Student")
                                {
                                    return RedirectToAction("StudentPage");
                                }   
                            }
                            
                        }
                    }
                }
            }           
            return View("Connexion");
        }
        
        public IActionResult TeacherPage()
        {
            return View("_Profs");
        }

        public IActionResult StudentPage()
        {
            return View("_Etudiants");
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult CourseSemesterGetAll()
        {
            HomeViewModel viewModel = HomeViewModel.getInstance();
            viewModel.CourseSemesterGetAll().Wait();

            return RedirectToAction("Index", "Home");
        }

        public IActionResult PersonGetAll()
        {
            HomeViewModel viewModel = HomeViewModel.getInstance();
            viewModel.PersonGetAll().Wait();

            return RedirectToAction("Index", "Home");
        }

        public IActionResult AddStudent(IFormCollection form)
        {
            HomeViewModel viewModel = HomeViewModel.getInstance();
            viewModel.UpdatePerson(form["FirstName"], form["LastName"], form["Phone"], form["Email"], "Student").Wait();
            viewModel.PersonGetAll().Wait();

            return RedirectToAction("Index", "Home");
        }
        public IActionResult Profs_preview()
        {
            return View("Profs_preview");
        }
    }
}