﻿namespace prjSessionCollege.JSON
{
    public class ResponseJSONDepartment
    {
    }
}
