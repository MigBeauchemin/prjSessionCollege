﻿namespace prjSessionCollege.JSON
{
    public class ResponseJSONSemester
    {
    }
}
