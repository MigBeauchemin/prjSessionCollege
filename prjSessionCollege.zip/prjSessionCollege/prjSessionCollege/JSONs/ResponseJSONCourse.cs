﻿namespace prjSessionCollege.JSON
{
    public class ResponseJSONCourse
    {
    }
}
